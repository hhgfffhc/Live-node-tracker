import LiveNodeTracker from '../components/LiveNodeTracker'

export default function Home() {
  return <LiveNodeTracker />
}
